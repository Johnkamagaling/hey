<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">
     <link rel="stylesheet" href="x.css">
    <title>Sales Page</title>
    <style>
        /* Define CSS styles for your table and its elements */

        body {
             height: 100vh;
             width: 100%;
             text-align: left;
             background-image: url("r.jpg");
             background-position: center;
             background-size: cover;
        }

        h1 {
            color:black;
            font-family: Arial, sans-serif;
            text-align: center;
            
        } 



        table {
            border-collapse: collapse;
            width: 10%;
            width: 70%;
            display: flex;
            justify-content: right;
            align-items: center;
            text-align: center;
            background-position: center;
            background-size: cover;
            margin: 0;
            padding: 0;
        }

        th, td {
            text-align: center;
            padding: 1px;
        }

        tr:nth-child(even) {
            
            
        }

        th {
            color: black;
        }
    </style>
</head>
<body>
<aside class="sidebar">
      <div class="logo">
        <img src="wrs.png" alt="logo">
        <h2>WRS</h2>
      </div>
      <ul class="links">
        <h4>Main Menu</h4>
        <li>
          <span class="material-symbols-outlined">dashboard</span>
          <a href="dashboard.php">Dashboard</a>
        </li>
        <li>
            <span class="material-symbols-outlined">group</span>
          <a href="#">Users</a>
        </li>
        <li>
          <span class="material-symbols-outlined">monitoring </span>
          <a href="sales.php">Sales</a>
        </li>
        <li>
          <span class="material-symbols-outlined">liquor </span>
          <a href="bottles_type.php">Bottletype</a>
        </li>
        <hr>
        
        <h4>Account</h4>
        <li>
          <span class="material-symbols-outlined">settings</span>
          <a href="settings.php">Settings</a>
        </li>
        <li class="logout-link">
          <span class="material-symbols-outlined">logout</span>
          <a href="logout.php">Logout</a>
        </li>
      </ul>
    </aside>
    
    <h1>Sales</h1>

    <!-- Create New Sale button/link -->
    <?php
    echo '<div style="text-align: right ;">';
    echo '<a href="addsale.php" style="text-decoration: none; background-color: #0072b8; color: white; padding: 5px 20px; border-radius: 19px;">Create New Sale</a>';
    echo '</div>';
    ?>

    <?php
// Connect to the database
$db = mysqli_connect('localhost', 'root', '', 'multi_login');

// Check the connection
if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

// SQL query to retrieve sales data
$sql = "SELECT * FROM sales";
$result = mysqli_query($db, $sql);

// Check if there are rows in the result set
if (mysqli_num_rows($result) > 0) {
    echo "<table>";
    echo "<tr><th>Customer</th><th>Type</th><th>Delivery_address</th><th>Status</th><th>Total_Item</th> <th>Amount</th><th>Action</th></tr>";

    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        
        echo "<td>" . $row["customer_name"] . "</td>";
        // Display "walk-in" for 1 and "for delivery" for 2
    echo "<td>";
    if ($row["type"] == 1) {
        echo "Walk-in";
    } elseif ($row["type"] == 2) {
        echo "For Delivery";
    } else {
        echo "Unknown"; // Handle other cases if needed
    }
    echo "</td>";

        echo "<td>" . $row["delivery_address"] . "</td>";
        echo "<td>" . $row["amount"] . "</td>";
        echo "<td>" . ($row["status"] == 0 ? "0" : ($row["status"] == 1 ? "1" : "")) . "</td>";

        // Add Edit and Delete links
        echo "<td>";
        echo "<a href='edit_sale.php?id=" . $row["id"] . "'>Edit</a> | ";


        // JavaScript function to confirm deletion
        echo "<td><a href='#' onclick=\"confirmDelete(" . $row["id"] . ");\">Delete</a></td>";
        echo "<script>
        function confirmDelete(saleId) {
        var confirmation = confirm('Are you sure to delete this Sales Transaction?');
        if (confirmation) {
        // If the user confirms, redirect to the delete script with the sale ID
        window.location.href = 'delete_sale.php?id=' + saleId;
    }
}
</script>";

// Add a link to go back to the sales page
echo "<a href='sales.php'></a>";

        echo "</td>";
        echo "</tr>";
    }
    
    echo "</table>";
} else {
    echo "No sales data available.";
}

// Close the database connection
mysqli_close($db);
?>

</body>
</html>
