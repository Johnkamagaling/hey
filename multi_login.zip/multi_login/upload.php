chmod -R 755 uploads/

$targetDirectory = "uploads/";
