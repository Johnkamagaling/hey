<!DOCTYPE html>
<html>
<head>
    <title>Add Sale Result</title>
</head>
<body>
    <h1>Add Sale Result</h1>

    <?php
// Connect to the database
$db = mysqli_connect('localhost', 'root', '', 'multi_login');

// Check the connection
if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get data from the form
$customer_name = $_POST['customer_name'];
$type = $_POST['type'];
$delivery_address = $_POST['delivery_address'];
$amount = $_POST['amount'];
$status = $_POST['status'];


// Insert the data into the sales table
$sql = "INSERT INTO sales (customer_name, type, delivery_address, amount, status) 
        VALUES ('$customer_name', '$type', '$delivery_address', $amount, $status)";

if (mysqli_query($db, $sql)) {
    echo "Sale added successfully.";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($db);
}

// Close the database connection
mysqli_close($db);
?>

    <!-- Link or button to go back to the sales form -->
    <a href="sales.php">Back to Sales Form</a>

</body>
</html>
