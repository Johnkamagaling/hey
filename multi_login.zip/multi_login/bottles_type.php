<!DOCTYPE html>
<html>
<head>
    <title>Bottle Types</title>
    <link rel="stylesheet" type="text/css" href="bottle.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">
     <link rel="stylesheet" href="x.css">
     <style>
        /* Define CSS styles for your table and its elements */

     

        h1 {
            color:black;
            font-family: Arial, sans-serif;
            text-align: center;
            
        } 

    </style>
</head>
<body>
<aside class="sidebar">
      <div class="logo">
        <img src="wrs.png" alt="logo">
        <h2>WRS</h2>
      </div>
      <ul class="links">
        <h4>Main Menu</h4>
        <li>
          <span class="material-symbols-outlined">dashboard</span>
          <a href="dashboard.php">Dashboard</a>
        </li>
        <li>
            <span class="material-symbols-outlined">group</span>
          <a href="#">Users</a>
        </li>
        <li>
          <span class="material-symbols-outlined">monitoring </span>
          <a href="sales.php">Sales</a>
        </li>
        <li>
          <span class="material-symbols-outlined">liquor </span>
          <a href="bottles_type.php">Bottletype</a>
        </li>
        <hr>
        
        <h4>Account</h4>
        <li>
          <span class="material-symbols-outlined">settings</span>
          <a href="settings.php">Settings</a>
        </li>
        <li class="logout-link">
          <span class="material-symbols-outlined">logout</span>
          <a href="logout.php">Logout</a>
        </li>
      </ul>
    </aside>

    <h1>List of Bottle Types & Pricing</h1>

<!-- Create New button -->
<?php
    echo '<div style="text-align: right;">';
    echo '<a href="create_new_bottle.php" style="text-decoration: none; background-color: #0072b8; color: white; padding: 5px 20px; border-radius: 19px;">Create New Sale</a>';
    echo '</div>';
    ?>

    <!-- Table to display bottle types -->
    <table border="1" class="center">
        <tr>
            <th>Image</th>
            <th>Name</th>
            <th>Description</th>
            <th>Price</th>
            <th>Action</th>
            <th>Date Created</th>
        </tr> 
        <?php
        // Connect to your database and fetch bottle type data
        $db = mysqli_connect('localhost', 'root', '', 'multi_login');
        $sql = "SELECT * FROM bottle_types";
        $result = mysqli_query($db, $sql);

        // Loop through the rows and display bottle type information
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td><img src='images/" . $row["image_filename"] . "' alt='" . $row["name"] . "' width='100'></td>"; // Replace 'images/' with your actual image folder path
            echo "<td>" . $row["name"] . "</td>";
            echo "<td>" . $row["description"] . "</td>";
            echo "<td>" . $row["price"] . "</td>";
             // Add Edit and Delete links
        echo "<td>";
        echo "<a href='edit_bottle_type.php?id=" . $row["id"] . "'>Edit</a> | ";


       // JavaScript function to confirm deletion
echo "<td><a href='#' onclick=\"confirmDelete(" . $row["id"] . ");\">Delete</a></td>";
echo "<script>
    function confirmDelete(bottleId) {
        var confirmation = confirm('Are you sure to delete this bottle?');
        if (confirmation) {
            // If the user confirms, redirect to the delete script with the bottle ID
            window.location.href = 'delete_bottle.php?id=' + bottleId;
        }
    }
</script>";
            echo "<td>" . $row["date_created"] . "</td>";
            echo "</tr>";
        }

        // Close the database connection
        mysqli_close($db);
        ?>
    </table>
</body>
</html>
