<!DOCTYPE html>
<html>
<head>
    <title>Edit Bottle Type</title>
</head>
<body>
    <h1>Edit Bottle Type</h1>

    <?php
    // Connect to the database
    $db = mysqli_connect('localhost', 'root', '', 'multi_login');

    // Check the connection
    if (!$db) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Check if the bottle type ID is provided as a query parameter
    if (isset($_GET['id'])) {
        $bottle_type_id = $_GET['id'];

        // SQL query to retrieve the bottle type details based on the provided ID
        $select_sql = "SELECT * FROM bottle_types WHERE id = $bottle_type_id";
        $result = mysqli_query($db, $select_sql);

        // Check if the bottle type record exists
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);

            // Handle form submission when the user updates the bottle type
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Retrieve the edited data from the form
                $edited_image_filename = $_POST['image_filename'];
                $edited_name = $_POST['name'];
                $edited_description = $_POST['description'];
                $edited_price = $_POST['price'];

                // SQL query to update the bottle type data
                $update_sql = "UPDATE bottle_types SET 
                    image_filename = '$edited_image_filename',
                    name = '$edited_name',
                    description = '$edited_description',
                    price = $edited_price
                    WHERE id = $bottle_type_id";

                if (mysqli_query($db, $update_sql)) {
                    // Bottle type updated successfully, redirect to the bottle types page
                    header("Location: bottles_type.php");
                    exit();
                } else {
                    echo "Error updating bottle type: " . mysqli_error($db);
                }
            }

            // Display a form with the existing data for editing
            echo "<form method='post' action=''>";
            echo "Image Filename: <input type='text' name='image_filename' value='" . $row["image_filename"] . "' required><br>";
            echo "Name: <input type='text' name='name' value='" . $row["name"] . "' required><br>";
            echo "Description: <input type='text' name='description' value='" . $row["description"] . "' required><br>";
            echo "Price: <input type='text' name='price' value='" . $row["price"] . "' required><br>";
            echo "<input type='submit' value='Save Changes'>";
            echo "</form>";
        } else {
            echo "Bottle type not found.";
        }
    } else {
        echo "Bottle Type ID not provided.";
    }

    // Close the database connection
    mysqli_close($db);
    ?>

    <!-- Add a link to go back to the bottle types page -->
    <a href="bottles_type.php">Back to Bottle Types Page</a>
</body>
</html>
