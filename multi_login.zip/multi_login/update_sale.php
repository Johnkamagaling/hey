<?php
// Connect to the database
$db = mysqli_connect('localhost', 'root', '', 'multi_login');

// Check the connection
if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the edited data from the form
    $sale_id = $_POST['sale_id'];
    $edited_customer_name = $_POST['customer_name'];
    // Retrieve other edited fields (type, delivery_address, amount, status, etc.)

    // SQL query to update the sale data
    $update_sql = "UPDATE sales SET customer_name = '$edited_customer_name', /* Update other fields here */ WHERE id = $sale_id";

    if (mysqli_query($db, $update_sql)) {
        // Sale updated successfully, redirect to the sales page
        header("Location: sales.php");
        exit();
    } else {
        echo "Error updating sale: " . mysqli_error($db);
    }
} else {
    echo "Invalid request.";
}

// Close the database connection
mysqli_close($db);
?>
