<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newUsername = $_POST['username'];
    $newEmail = $_POST['email'];
    
    // Handle avatar upload
    $avatarUploadDir = 'uploads/'; // Define your upload directory
    $avatarFileName = $_FILES['avatar']['name'];
    $avatarTempName = $_FILES['avatar']['tmp_name'];
    $avatarPath = $avatarUploadDir . $avatarFileName;
    
    if (move_uploaded_file($avatarTempName, $avatarPath)) {
        // Avatar uploaded successfully
        
        $db = mysqli_connect('localhost', 'root', '', 'multi_login');
        
        if (!$db) {
            die("Database connection failed: " . mysqli_connect_error());
        }
        // Update user profile information, including the avatar path, in your database
        $sql = "UPDATE users SET username='$newUsername', email='$newEmail', avatar='$avatarPath' WHERE id=1";
        
        if (mysqli_query($db, $sql)) {
            // Success
            // Redirect to the profile_updated.php page with a success message as a query parameter
            header('Location: profile_updated.php?success=1');
        } else {
            echo 'Profile update failed: ' . mysqli_error($db);
        }
        
        mysqli_close($db); // Close the database connection
    } else {
        echo 'Avatar upload failed. Please try again.';
    }
}
?>
