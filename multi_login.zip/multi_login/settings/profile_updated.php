
<!DOCTYPE html>
<html>
<head>
    <title>Profile Updated</title>
</head>
<body>
    <h1>Profile Updated Successfully</h1>
    <p>System Info Successfully Updated</p>

    <a href="settings.php">Back to the previous page</a>
</body>
</html>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newUsername = $_POST['username'];
    $newEmail = $_POST['email'];
    $newpassword = $_POST['password'];
    $Confirmnewpassword = $_POST['password'];
    
    // Perform database update or user profile update logic here
    // For example, you might use SQL queries to update user information in a database.
    
    // Redirect to a confirmation page after successful update
    header('Location: profile_updated.php');
}

if (isset($_GET['success']) && $_GET['success'] == 1) {
    echo 'System Info Successfully Updated';
}

?>