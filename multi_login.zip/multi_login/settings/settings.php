<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">
    <link rel="stylesheet" href="x.css">
    <link rel="stylesheet" type="text/css" href="settings.css">
    <script>
        function validateForm() {
            var password = document.getElementById("password").value;
            var confirmPassword = document.getElementById("confirmpassword").value;

            if (password !== confirmPassword) {
                alert("Passwords do not match");
                return false;
            }
            return true;
        }
    </script>
</head>
<body>
<aside class="sidebar">
      <div class="logo">
        <img src="wrs.png" alt="logo">
        <h2>WRS</h2>
      </div>
      <ul class="links">
        <h4>Main Menu</h4>
        <li>
          <span class="material-symbols-outlined">dashboard</span>
          <a href="dashboard.php">Dashboard</a>
        </li>
        <li>
            <span class="material-symbols-outlined">group</span>
          <a href="#">Users</a>
        </li>
        <li>
          <span class="material-symbols-outlined">monitoring </span>
          <a href="sales.php">Sales</a>
        </li>
        <li>
          <span class="material-symbols-outlined">liquor </span>
          <a href="bottles_type.php">Bottletype</a>
        </li>
        <hr>
        
        <h4>Account</h4>
        <li>
          <span class="material-symbols-outlined">settings</span>
          <a href="settings.php">Settings</a>
        </li>
        <li class="logout-link">
          <span class="material-symbols-outlined">logout</span>
          <a href="logout.php">Logout</a>
        </li>
      </ul>
    </aside>
    <div class="profile-container">
        <h1>Profile Settings</h1>
        <form action="update_profile.php" method="post" enctype="multipart/form-data" onsubmit="return validateForm()">
            <label for="username">Username:</label>
            <input type="text" name="username" id="username" value="CurrentUsername">

            <label for="email">Email:</label>
            <input type="email" name="email" id="email" value="user@example.com">

            <label for="password">Password:</label>
            <input type="password" name="password" id="password" value="">
            
            <label for="confirmpassword">Confirm Password:</label>
            <input type="password" name="confirmpassword" id="confirmpassword" value="">

            <label for="avatar">Avatar:</label>
            <img src="<?php echo $avatarPath; ?>" alt="User Avatar" width="100">
            <input type="file" name="avatar" id="avatar">

        
            <input type="submit" value="Update Profile">
        </form>
    </div>
</body>
</html>
