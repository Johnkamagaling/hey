<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connect to your database
    $db = mysqli_connect('localhost', 'root', '', 'multi_login');

    // Check if the connection was successful
    if (!$db) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Retrieve form data
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $image = $_FILES['image']['name']; // Get the name of the uploaded image file

    // Move the uploaded image to your images folder
    move_uploaded_file($_FILES['image']['tmp_name'], 'images/' . $image);

    // SQL query to insert the new bottle type into the database
    $sql = "INSERT INTO bottle_types (name, description, price, image_filename, date_created)
            VALUES ('$name', '$description', $price, '$image', NOW())";

    if (mysqli_query($db, $sql)) {
        // Redirect back to the bottle list page on successful insertion
        header("Location: bottles_type.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($db);
    }

    // Close the database connection
    mysqli_close($db);
}
?>
