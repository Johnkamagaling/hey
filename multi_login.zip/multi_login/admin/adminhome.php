<!DOCTYPE html>
<html>
<head>
    <title>Admin Home</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">
    <link rel="stylesheet" href="index.css">
</head>
<body>

<h1>Welcome, Admin!</h1> <style>   body {
            display: flex;
            justify-content: center; /* Horizontal centering */
                        
        }</style>
        
<aside class="sidebar">
      <div class="logo">
        <img src="wrs.png" alt="logo">
        <h2>WRS</h2>
      </div>
      <ul class="links">
        <h4>Main Menu</h4>
        <li>
          <span class="material-symbols-outlined">dashboard</span>
          <a href="dashboard.php">Dashboard</a>
        </li>
        <li>
            <span class="material-symbols-outlined">group</span>
          <a href="#">Users</a>
        </li>
        <li>
          <span class="material-symbols-outlined">monitoring </span>
          <a href="sales.php">Sales</a>
        </li>
        <li>
          <span class="material-symbols-outlined">liquor </span>
          <a href="bottles_type.php">Bottletype</a>
        </li>
        <hr>
        
        <h4>Account</h4>
        <li>
          <span class="material-symbols-outlined">settings</span>
          <a href="settings.php">Settings</a>
        </li>
        <li class="logout-link">
          <span class="material-symbols-outlined">logout</span>
          <a href="logout.php">Logout</a>
        </li>
      </ul>
    </aside>
</body>
</html>
