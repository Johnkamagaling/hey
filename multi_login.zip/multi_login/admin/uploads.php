$avatarUploadDir = 'uploads/';
$avatarUploadDir = 'C:/xampp/htdocs/multi_login/uploads/';
