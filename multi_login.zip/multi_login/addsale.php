<!DOCTYPE html>
<html>
<head>
    <title>Add Sale</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">
     <link rel="stylesheet" href="x.css">

<style>
    body {
    height: 100vh;
    width: 10   0%;
    background-image: url("r.jpg");
    background-position: center;
    background-size: cover;
    text-align: center;
}
</style>

</head>
<body>
    <aside class="sidebar">
        <div class="logo">
          <img src="wrs.png" alt="logo">
          <h2>WRS</h2>
        </div>
        <ul class="links">
          <h4>Main Menu</h4>
          <li>
            <span class="material-symbols-outlined">dashboard</span>
            <a href="dashboard.php">Dashboard</a>
          </li>
          <li>
              <span class="material-symbols-outlined">group</span>
            <a href="#">Users</a>
          </li>
          <li>
            <span class="material-symbols-outlined">monitoring </span>
            <a href="sales.php">Sales</a>
          </li>
          <li>
            <span class="material-symbols-outlined">liquor </span>
            <a href="bottles_type.php">Bottletype</a>
          </li>
          <hr>
          
          <h4>Account</h4>
          <li>
            <span class="material-symbols-outlined">settings</span>
            <a href="settings.php">Settings</a>
          </li>
          <li class="logout-link">
            <span class="material-symbols-outlined">logout</span>
            <a href="logout.php">Logout</a>
          </li>
        </ul>
      </aside>
  
    <h1>Add Sale</h1>
    <form action="process_sale.php" method="post">
        <label for="customer_name">Customer Name:</label>
        <input type="text" id="customer_name" name="customer_name" required><br>
        
        <label for="type">Type:</label>
        <select id="type" name="type" required>
        <option value="1">Walk-in</option>
        <option value="2">For Delivery</option>
        </select><br>
        
        <label for="delivery_address">Delivery Address:</label>
        <input type="text" id="delivery_address" name="delivery_address" required><br>

                        <label class="control-label">Bottles</label>
                        <select  id="bottles_type_id" class="custom-select select2">
                            <option value=""></option></select>
      

        <label for="quantity">Quantity:</label>
        <input type="number" id="quantity" name="quantityt" required><br>
        
        <label for="amount">Amount:</label>
        <input type="number" id="amount" name="amount" required><br>
        
        <label for="status">Status:</label>
        <select id="status" name="status" required>
        <option value="0">Unpaid</option>
        <option value="1">Paid</option>
        </select><br>

        <input type="submit" value="Create New">
    </form>
</body>
</html>
