<!DOCTYPE html>
<html>
<head>
    <title>Edit Sale</title>
</head>
<body>
    <h1>Edit Sale</h1>

    <?php
    // Connect to the database
    $db = mysqli_connect('localhost', 'root', '', 'multi_login');

    // Check the connection
    if (!$db) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Check if the sale ID is provided as a query parameter
    if (isset($_GET['id'])) {
        $sale_id = $_GET['id'];

        // SQL query to retrieve the sale details based on the provided ID
        $select_sql = "SELECT * FROM sales WHERE id = $sale_id";
        $result = mysqli_query($db, $select_sql);

        // Check if the sale record exists
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);

            // Handle form submission when the user updates the sale
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Retrieve the edited data from the form
                $edited_customer_name = $_POST['customer_name'];
                $edited_type = $_POST['type'];
                $edited_delivery_address = $_POST['delivery_address'];
                $edited_amount = $_POST['amount'];
                $edited_status = $_POST['status'];
                $edited_total_amount = $_POST['total_amount'];

                // SQL query to update the sale data
                $update_sql = "UPDATE sales SET 
                customer_name = '$edited_customer_name',
                type = '$edited_type',
                delivery_address = '$edited_delivery_address',
                amount = $edited_amount,
                status = '$edited_status',
                total_amount = $edited_total_amount
                WHERE id = $sale_id";
            

                if (mysqli_query($db, $update_sql)) {
                    // Sale updated successfully, redirect to the sales page
                    header("Location: sales.php");
                    exit();
                } else {
                    echo "Error updating sale: " . mysqli_error($db);
                }
            }

            // Display a form with the existing data for editing
            echo "<form method='post' action=''>";
            echo "Customer Name: <input type='text' name='customer_name' value='" . $row["customer_name"] . "' required><br>";
            echo "Type: <input type='text' name='type' value='" . $row["type"] . "' required><br>";
            echo "Delivery Address: <input type='text' name='delivery_address' value='" . $row["delivery_address"] . "' required><br>";
            echo "Amount: <input type='text' name='amount' value='" . $row["amount"] . "' required><br>";
            echo "Status: <input type='text' name='status' value='" . $row["status"] . "' required><br>";
            echo "Total_Amount: <input type='text' name='total_amount' value='" . (isset($row["total_amount"]) ? $row["total_amount"] : '') . "' required><br>";
            echo "<input type='submit' value='Save Changes'>";
            echo "</form>";
        } else {
            echo "Sale not found.";
        }
    } else {
        echo "Sale ID not provided.";
    }

    // Close the database connection
    mysqli_close($db);
    ?>

    <!-- Add a link to go back to the sales page -->
    <a href="sales.php">Back to Sales Page</a>
</body>
</html>
