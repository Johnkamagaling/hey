<?php
// Connect to the database
$db = mysqli_connect('localhost', 'root', '', 'multi_login');

// Check the connection
if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the bottles ID is provided as a query parameter
if (isset($_GET['id'])) {
    $bottle_id = $_GET['id'];

    // SQL query to delete the bottles
    $delete_sql = "DELETE FROM bottle_types WHERE id = $bottle_id";

    if (mysqli_query($db, $delete_sql)) {
        // Bottle deleted successfully, redirect to the bottles page
        header("Location: bottles_type.php");
        exit(); // Make sure to exit after redirecting
    } else {
        echo "Error deleting bottles: " . mysqli_error($db);
    }
} else {
    echo "Bottle ID not provided.";
}

// Close the database connection
mysqli_close($db);
?>
