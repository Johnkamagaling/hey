<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8sh+5nD5F5P4f5C9R5EMsaa6U6fG5f5F5R5F5E5" crossorigin="anonymous">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">
     <link rel="stylesheet" href="x.css">
<title>Sales Dashboard</title>
    <style>
        /* Define CSS styles for your dashboard elements */
        body {
            font-family: Arial, sans-serif;
            height: 100vh;
            background-image: url("r.jpg");
            background-position: center;
            background-size: cover;
            
        }
        h1 {
            color:black;
            font-family: Arial, sans-serif;
            text-align: center;
        }
        
        .container {
            width: 50%;
            margin: 0 auto;
            padding: 20px;
        }

        .total-sales {
            font-size: 24px;
            font-weight: bold;
            
        }

    </style>

    
</head>
<body>
<aside class="sidebar">
      <div class="logo">
        <img src="wrs.png" alt="logo">
        <h2>WRS</h2>
      </div>
      <ul class="links">
        <h4>Main Menu</h4>
        <li>
          <span class="material-symbols-outlined">dashboard</span>
          <a href="dashboard.php">Dashboard</a>
        </li>
        <li>
            <span class="material-symbols-outlined">group</span>
          <a href="#">Users</a>
        </li>
        <li>
          <span class="material-symbols-outlined">monitoring </span>
          <a href="sales.php">Sales</a>
        </li>
        <li>
          <span class="material-symbols-outlined">liquor </span>
          <a href="bottles_type.php">Bottletype</a>
        </li>
        <hr>
        
        <h4>Account</h4>
        <li>
          <span class="material-symbols-outlined">settings</span>
          <a href="settings.php">Settings</a>
        </li>
        <li class="logout-link">
          <span class="material-symbols-outlined">logout</span>
          <a href="logout.php">Logout</a>
        </li>
      </ul>
    </aside>
    <h1>Welcome to Simple Water Refilling Management System</h1>

    <div class="container">
    <h1><i class="sales-icon fas fa-chart-line"></i> Total Sales Today</h1>
        <?php
        // Connect to the database
        $db = mysqli_connect('localhost', 'root', '', 'multi_login');

        // Check the connection
        if (!$db) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // SQL query to calculate the total sales
        $sql = "SELECT SUM(amount) AS total_sales FROM sales";
        $result = mysqli_query($db, $sql);

        if ($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            echo "<p class='total-sales'>P" . number_format($row['total_sales'], 2) . "</p>"; // Format as currency
        } else {
            echo "<p class='total-sales'>P0.00</p>";
        }

        // Close the database connection
        mysqli_close($db);
        ?>
    </div>
</body>
</html>
