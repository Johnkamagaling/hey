<?php
// Connect to the database
$db = mysqli_connect('localhost', 'root', '', 'multi_login');

// Check the connection
if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the sale ID is provided as a query parameter
if (isset($_GET['id'])) {
    $sale_id = $_GET['id'];

    // SQL query to delete the sale
    $delete_sql = "DELETE FROM sales WHERE id = $sale_id";

    if (mysqli_query($db, $delete_sql)) {
        // Sale deleted successfully, redirect to the sales page
        header("Location: sales.php");
        exit(); // Make sure to exit after redirecting
    } else {
        echo "Error deleting sale: " . mysqli_error($db);
    }
} else {
    echo "Sale ID not provided.";
}

// Close the database connection
mysqli_close($db);
?>
