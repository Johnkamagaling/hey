<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create New Product</title>
    <!-- Include any necessary CSS and JavaScript libraries here -->
    <style>
        /* Add your CSS styles here */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        h1 {
            text-align: center;
            margin-top: 20px;
        }

        .create-new-form {
            width: 60%;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
        }

        .create-new-button {
            text-align: center;
            margin-top: 20px;
        }

        .create-new-button a {
            display: inline-block;
            padding: 10px 20px;
            background-color: #333;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }

        .create-new-button a:hover {
            background-color: #555;
        }

        /* You can add more styles as needed */
    </style>
</head>
<body>
    <h1>Add New Bottle Type & Pricing</h1>

    <!-- Create New Product Form -->
    <div class="create-new-form">
        <form method="post" action="process_add_bottle.php" enctype="multipart/form-data">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required><br>

            <label for="description">Description:</label>
            <textarea id="description" name="description" rows="4" required></textarea><br>

            <label for="price">Price:</label>
            <input type="number" id="price" name="price" step="0.01" required><br>

            <label for="image">Image:</label>
            <input type="file" id="image" name="image" accept="image/*" required><br>

            <button type="submit">Save</button>
    

             <!-- Add a Cancel button -->
        <a href="bottles_type.php">Cancel</a>
        </form>
    </div>
</body>
</html>
